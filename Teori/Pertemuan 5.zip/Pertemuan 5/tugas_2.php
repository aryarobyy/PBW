<?php
    $n = -5;

    if($n < 0){
        echo "$n adalah Negative\n";
    } else if ($n == 0) {
        echo "$n adalah Nol\n";
    } else {
        echo "$n adalah Positive\n";
    }
?>